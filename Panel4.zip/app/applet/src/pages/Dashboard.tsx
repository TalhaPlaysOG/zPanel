import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Terminal, Activity, MapPin, ArrowUpRight, Shield, ChevronDown, ArrowRight, Server, Zap, Cpu, HardDrive, Wifi, Radio } from 'lucide-react';
import { useDashboardData } from '../hooks/useDashboardData';
import { useSettings } from '../context/SettingsContext';
import { useAuth } from '../context/AuthContext';

const feedA = [
    ['https://w.wallhaven.cc/full/1q/wallhaven-1qgvrg.jpg','MC_01','MINECRAFT // OVERWORLD'],
    ['https://w.wallhaven.cc/full/w5/wallhaven-w5dwyx.png','MC_02','MINECRAFT // SURVIVAL'],
    ['https://w.wallhaven.cc/full/7j/wallhaven-7jeldy.png','MC_03','MINECRAFT // CREATIVE'],
    ['https://w.wallhaven.cc/full/gw/wallhaven-gwmwr3.png','MC_04','MINECRAFT // CAVES'],
];
const feedB = [
    ['https://w.wallhaven.cc/full/og/wallhaven-og6gz9.png','MC_05','MINECRAFT // LANDSCAPE'],
    ['https://w.wallhaven.cc/full/ly/wallhaven-lyjyll.png','MC_06','MINECRAFT // SHADERS'],
    ['https://w.wallhaven.cc/full/je/wallhaven-jeye2m.png','MC_07','MINECRAFT // EXPLORE'],
    ['https://w.wallhaven.cc/full/7j/wallhaven-7je6jo.png','MC_08','MINECRAFT // MULTIPLAYER'],
];

const feedA = [
    ['https://w.wallhaven.cc/full/1q/wallhaven-1qgvrg.jpg','MC_01','MINECRAFT // OVERWORLD'],
    ['https://w.wallhaven.cc/full/w5/wallhaven-w5dwyx.png','MC_02','MINECRAFT // SURVIVAL'],
    ['https://w.wallhaven.cc/full/7j/wallhaven-7jeldy.png','MC_03','MINECRAFT // CREATIVE'],
    ['https://w.wallhaven.cc/full/gw/wallhaven-gwmwr3.png','MC_04','MINECRAFT // CAVES'],
];

const feedB = [
    ['https://w.wallhaven.cc/full/og/wallhaven-og6gz9.png','MC_05','MINECRAFT // LANDSCAPE'],
    ['https://w.wallhaven.cc/full/ly/wallhaven-lyjyll.png','MC_06','MINECRAFT // SHADERS'],
    ['https://w.wallhaven.cc/full/je/wallhaven-jeye2m.png','MC_07','MINECRAFT // EXPLORE'],
    ['https://w.wallhaven.cc/full/7j/wallhaven-7je6jo.png','MC_08','MINECRAFT // MULTIPLAYER'],
];

const tickerItems = [
    { label: 'UPTIME 99.98%', color: 'text-emerald-400', dot: 'bg-emerald-400 shadow-[0_0_6px_#34d399]' },
    { label: 'NODES 3/3 ACTIVE', color: 'text-cyan-400', dot: 'bg-cyan-400 shadow-[0_0_6px_#38bdf8]' },
    { label: 'LATENCY 11MS', color: 'text-indigo-400', dot: 'bg-indigo-400 shadow-[0_0_6px_#818cf8]' },
    { label: 'PACKETS 4.2M/S', color: 'text-sky-400', dot: 'bg-sky-400 shadow-[0_0_6px_#38bdf8]' },
    { label: 'DDOS SHIELD ARMED', color: 'text-purple-400', dot: 'bg-purple-400 shadow-[0_0_6px_#c084fc]' },
    { label: 'BACKUP SYNCED 04:00 UTC', color: 'text-teal-400', dot: 'bg-teal-400 shadow-[0_0_6px_#2dd4bf]' },
    { label: 'US-EAST NOMINAL', color: 'text-emerald-400', dot: 'bg-emerald-400 shadow-[0_0_6px_#34d399]' },
    { label: 'EU-WEST NOMINAL', color: 'text-emerald-400', dot: 'bg-emerald-400 shadow-[0_0_6px_#34d399]' },
    { label: 'AP-SOUTH DEGRADED', color: 'text-amber-400', dot: 'bg-amber-400 shadow-[0_0_6px_#fbbf24]' },
    { label: 'FIRMWARE STABLE', color: 'text-blue-400', dot: 'bg-blue-400 shadow-[0_0_6px_#60a5fa]' }
];

const sparkColors = ['#10b981', '#06b6d4', '#818cf8', '#a855f7', '#38bdf8'];

const rand = (a: number, b: number) => Math.floor(a + Math.random()*(b-a));

function spark(seed: number, strokeColor = "#06b6d4") {
    let pts=[], v=18+(seed%5)*3;
    for(let i=0;i<24;i++){
        v = Math.max(4, Math.min(32, v + (Math.random()-0.48)*9));
        pts.push(`${(i*(120/23)).toFixed(1)},${(36-v).toFixed(1)}`);
    }
    const fillPts = `0,35 ${pts.join(' ')} 120,35`;
    const gradId = `spark-grad-${seed}`;
    return (
        <svg viewBox="0 0 120 36" className="w-full h-9 overflow-visible" preserveAspectRatio="none">
            <defs>
                <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={strokeColor} stopOpacity="0.4" />
                    <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
                </linearGradient>
            </defs>
            <polygon points={fillPts} fill={`url(#${gradId})`} />
            <line x1="0" y1="35" x2="120" y2="35" stroke="rgba(255,255,255,0.1)" strokeWidth="1"/>
            <polyline points={pts.join(' ')} fill="none" stroke={strokeColor} strokeWidth="1.75" className="spark"/>
        </svg>
    );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { servers: rawServers } = useDashboardData();
  const realServers = Array.isArray(rawServers) ? rawServers : [];
  const { panelName } = useSettings();
  const pName = panelName || 'zPanel';
  const nameParts = pName.includes(' ') ? pName.split(' ') : ['Z', (pName.startsWith('z') || pName.startsWith('Z')) && pName.length > 1 ? pName.slice(1) : 'PANEL'];
  const firstWord = nameParts[0].toUpperCase();
  const restWords = nameParts.slice(1).join(' ').toUpperCase() || 'PANEL';

  const [uptimeStr, setUptimeStr] = useState('247:13:08');
  const [pkts, setPkts] = useState(4213377);
  const uptimeRef = useRef(247*3600 + 13*60 + 8);
  const pktsRef = useRef(4213377);
  const [vitals, setVitals] = useState({ cpu: 42, mem: 68, net: 28, lat: 11 });

  // Bootlog
  const [bootlogLines, setBootlogLines] = useState<string[]>([]);
  
  useEffect(() => {
    let unmounted = false;
    const linesToPrint = [
      '> SYSTEM.CORE — bootstrap sequence',
      '> mounting node registry ............. OK',
      '> establishing secure uplink ......... OK',
      '> syncing telemetry stream ........... OK',
      '> handshake 3/3 primary nodes ........ OK',
      '> ACCESS GRANTED — welcome, commander',
    ];

    const runBootlog = async () => {
      let currentLines: string[] = [];
      for (const line of linesToPrint) {
        currentLines = [...currentLines, line];
        if (unmounted) return;
        setBootlogLines([...currentLines]);
        await new Promise(r => setTimeout(r, 240 + line.length * 13));
      }
    };
    runBootlog();
    return () => { unmounted = true; };
  }, []);

  useEffect(() => {
    const upInt = setInterval(() => {
        uptimeRef.current++;
        const up = uptimeRef.current;
        const h = String(Math.floor(up/3600)).padStart(3,'0');
        const m = String(Math.floor(up/60)%60).padStart(2,'0');
        const s = String(up%60).padStart(2,'0');
        setUptimeStr(`${h}:${m}:${s}`);
    }, 1000);

    const pktsInt = setInterval(() => {
        pktsRef.current += rand(600,2400);
        setPkts(pktsRef.current);
    }, 300);

    const vitalsInt = setInterval(() => {
        setVitals({
            cpu: rand(28,74),
            mem: rand(50,88),
            net: rand(12,64),
            lat: rand(9,17)
        });
    }, 2600);

    return () => {
        clearInterval(upInt);
        clearInterval(pktsInt);
        clearInterval(vitalsInt);
    };
  }, []);

  useEffect(() => {
    const mainEl = document.querySelector('main');
    const io = new IntersectionObserver(entries => {
        entries.forEach(e => {
            if (e.isIntersecting) {
                e.target.classList.add('active');
                io.unobserve(e.target);
            }
        });
    }, { root: mainEl, threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [realServers]);

  useEffect(() => {
    const mainEl = document.querySelector('main');
    if (!mainEl) return;
    const handleScroll = () => {
        const p = mainEl.scrollTop / (mainEl.scrollHeight - mainEl.clientHeight);
        const el = document.getElementById('scroll-progress');
        if (el) el.style.transform = `scaleX(${Math.min(p, 1)})`;
    };
    mainEl.addEventListener('scroll', handleScroll, { passive: true });
    return () => mainEl.removeEventListener('scroll', handleScroll);
  }, []);

  // Format real servers
  const mappedServers = useMemo(() => realServers.map((s, i) => {
    return {
        rank: String(i + 1).padStart(2, '0'),
        rawId: s.id,
        name: s.name,
        id: s.id.substring(0, 8).toUpperCase(),
        region: 'LOCAL',
        load: Math.round(s.cpu || rand(10, 80)),
        mem: Math.round(s.memory || rand(20, 90)),
        uptime: '99.99',
        status: (s.status || 'OFFLINE').toUpperCase(),
        owner: s.owner
    };
  }), [realServers]);

  // Top servers: User's own servers
  const myServers = useMemo(() => {
    if (!user) return mappedServers;
    return mappedServers.filter(s => {
      if (!s.owner) return true;
      return s.owner === user.id || s.owner === user.username || s.owner === user.email;
    });
  }, [mappedServers, user]);

  // Operator servers: Servers belonging to other operators/users or shared
  const operatorServers = useMemo(() => {
    if (!user) return [];
    return mappedServers.filter(s => {
      return s.owner && s.owner !== user.id && s.owner !== user.username && s.owner !== user.email;
    });
  }, [mappedServers, user]);

  const uniqueOwners = useMemo(() => {
    const map = new Map<string, {init:string, name:string, role:string, clr:string, ping:string, on:boolean, serverCount:number, primaryServerId?:string}>();
    realServers.forEach(s => {
      const owner = s.owner || 'ADMIN';
      if (!map.has(owner)) {
        map.set(owner, {
          init: owner.substring(0, 2).toUpperCase(),
          name: owner.toUpperCase(),
          role: 'SERVER OPERATOR',
          clr: 'L2',
          ping: 'NOW',
          on: s.status === 'online',
          serverCount: 1,
          primaryServerId: s.id
        });
      } else {
        const item = map.get(owner)!;
        item.serverCount += 1;
        if (s.status === 'online') {
            item.on = true;
        }
      }
    });
    return Array.from(map.values());
  }, [realServers]);

  return (
    <div className="text-white font-body min-h-full relative selection:bg-indigo-500 selection:text-white">
      <style dangerouslySetInnerHTML={{__html: `
        ::-webkit-scrollbar { width:6px; }
        ::-webkit-scrollbar-track { background:#05070f; }
        ::-webkit-scrollbar-thumb { background:#1e293b; border-radius:3px; }
        ::-webkit-scrollbar-thumb:hover { background:#38bdf8; }

        .bg-grid {
            position:absolute; inset:0; z-index:0; pointer-events:none;
            background-image:
                linear-gradient(rgba(56,189,248,.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(56,189,248,.04) 1px, transparent 1px);
            background-size:56px 56px;
            -webkit-mask-image:radial-gradient(ellipse 95% 75% at 50% 0%, #000 35%, transparent 85%);
                    mask-image:radial-gradient(ellipse 95% 75% at 50% 0%, #000 35%, transparent 85%);
        }
        .scanline {
            position:absolute; left:0; right:0; height:140px; top:-140px; z-index:1; pointer-events:none;
            background:linear-gradient(to bottom, transparent, rgba(56,189,248,.04), transparent);
            animation:scan 9s linear infinite;
        }
        @keyframes scan { to { top:100vh; } }
        .noise {
            position:absolute; inset:0; z-index:60; pointer-events:none; opacity:.025;
            background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.7' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
        }
        #scroll-progress {
            position:fixed; top:0; left:0; height:3px; width:100%; z-index:100;
            background:linear-gradient(90deg, #6366f1, #06b6d4, #10b981);
            transform-origin:left; transform:scaleX(0);
            box-shadow:0 0 14px rgba(6,182,212,.8);
        }
        .outline-text { -webkit-text-stroke:1.5px #38bdf8; color:transparent; }
        .outline-num  { -webkit-text-stroke:1px rgba(99,102,241,0.6); color:transparent; transition:all .3s; }
        .group:hover .outline-num { -webkit-text-stroke-color:#38bdf8; filter:drop-shadow(0 0 8px rgba(56,189,248,0.5)); }
        .outline-faint { -webkit-text-stroke:1px rgba(255,255,255,0.08); color:transparent; }
        
        .reveal { opacity:0; transform:translateY(36px); transition:opacity .9s cubic-bezier(.16,1,.3,1), transform .9s cubic-bezier(.16,1,.3,1); }
        .reveal.active { opacity:1; transform:translateY(0); }
        
        .ticker-track, .marquee { display:flex; width:max-content; }
        .ticker-track { animation:mq 32s linear infinite; }
        .marquee      { gap:24px; animation:mq 48s linear infinite; }
        .marquee.rev  { animation-direction:reverse; animation-duration:58s; }
        .ticker-track:hover, .marquee:hover { animation-play-state:paused; }
        @keyframes mq { to { transform:translateX(-50%); } }

        .cursor-blink { animation:blink 1s steps(1) infinite; }
        @keyframes blink { 50% { opacity:0; } }

        .pulse-dot { animation:pd 2.4s infinite; }
        @keyframes pd {
            0%,100% { box-shadow:0 0 0 0 rgba(52,211,153,.5); }
            50%     { box-shadow:0 0 0 8px rgba(52,211,153,0); }
        }

        .spark { stroke-dasharray:280; stroke-dashoffset:280; }
        .active .spark { animation:draw 1.8s cubic-bezier(.16,1,.3,1) .35s forwards; }
        @keyframes draw { to { stroke-dashoffset:0; } }

        .loadbar { width:0; transition:width 1.4s cubic-bezier(.16,1,.3,1) .45s; }
        .active .loadbar { width:var(--w); }

        .tbar { transition:width 1.6s cubic-bezier(.16,1,.3,1); }

        .btn-sweep { position:relative; overflow:hidden; }
        .btn-sweep::before { content:''; position:absolute; inset:0; background:linear-gradient(90deg, #4f46e5, #0284c7); transform:translateY(101%); transition:transform .35s cubic-bezier(.16,1,.3,1); }
        .btn-sweep:hover::before { transform:translateY(0); }
        .btn-sweep :is(span, svg) { position:relative; z-index:1; transition:color .35s; }

        .bw-img { filter:grayscale(0.6) contrast(1.1) brightness(.85); transition:filter .7s cubic-bezier(.16,1,.3,1), transform .7s cubic-bezier(.16,1,.3,1); }
        .group:hover .bw-img { filter:grayscale(0) contrast(1) brightness(1.05); transform:scale(1.05); }

        .corner { position:absolute; width:12px; height:12px; }
        .c-tl { top:-1px; left:-1px; border-top:2px solid #38bdf8; border-left:2px solid #38bdf8; }
        .c-tr { top:-1px; right:-1px; border-top:2px solid #38bdf8; border-right:2px solid #38bdf8; }
        .c-bl { bottom:-1px; left:-1px; border-bottom:2px solid #38bdf8; border-left:2px solid #38bdf8; }
        .c-br { bottom:-1px; right:-1px; border-bottom:2px solid #38bdf8; border-right:2px solid #38bdf8; }
      `}} />

      <div className="noise" />
      <div className="bg-grid" />
      <div className="scanline" />
      <div id="scroll-progress" />

      <div className="relative z-10">
        
        {/* TICKER */}
        <div className="border-b border-indigo-500/20 bg-slate-950/70 backdrop-blur-md overflow-hidden flex">
            <div className="ticker-track">
                {[...tickerItems, ...tickerItems].map((x, i) => (
                    <span key={i} className="flex items-center gap-2.5 px-5 py-2.5 font-mono text-[11px] tracking-widest whitespace-nowrap border-r border-indigo-500/10">
                        <span className={`w-1.5 h-1.5 rounded-full ${x.dot}`}></span> 
                        <span className={`font-semibold ${x.color}`}>{x.label}</span>
                    </span>
                ))}
            </div>
        </div>

        {/* HEADER */}
        <header className="max-w-7xl mx-auto px-5 md:px-8 pt-16 md:pt-24 pb-20">
            <div className="grid lg:grid-cols-12 gap-12 items-start">

                <div className="lg:col-span-12 reveal active max-w-4xl">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-mono text-xs tracking-wider mb-6 shadow-[0_0_15px_rgba(99,102,241,0.2)]">
                        <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                        <span>SYSTEM.CORE — <span className="text-emerald-400 font-bold">ACCESS GRANTED</span></span>
                    </div>

                    <h1 className="font-display font-bold leading-[0.85] tracking-tight text-[clamp(4.5rem,11vw,8.5rem)] uppercase">
                        <span className="block bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">{firstWord}</span>
                        <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-cyan-400 to-emerald-400 drop-shadow-[0_0_35px_rgba(56,189,248,0.25)]">{restWords}</span>
                    </h1>

                    <p className="mt-8 text-slate-300 font-light text-base md:text-lg max-w-xl leading-relaxed">
                        Unified command surface for your global node network.
                        Telemetry, operators and visual feed — enhanced with live cloud intelligence.
                    </p>

                    {/* Terminal Boot Log */}
                    <div className="relative border border-cyan-500/20 bg-slate-950/80 backdrop-blur-xl mt-10 max-w-xl rounded-xl overflow-hidden shadow-[0_0_30px_rgba(6,182,212,0.1)]">
                        <span className="corner c-tl"></span><span className="corner c-tr"></span>
                        <span className="corner c-bl"></span><span className="corner c-br"></span>
                        
                        <div className="flex items-center justify-between border-b border-indigo-500/20 bg-slate-900/60 px-4 py-2.5">
                            <span className="font-mono text-[11px] text-cyan-400 font-semibold tracking-widest flex items-center gap-2">
                                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> BOOT.LOG
                            </span>
                            <span className="flex gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-rose-500/80"></span>
                                <span className="w-2 h-2 rounded-full bg-amber-500/80"></span>
                                <span className="w-2 h-2 rounded-full bg-emerald-500/80"></span>
                            </span>
                        </div>

                        <div className="font-mono text-[12px] leading-6 p-4 min-h-[185px] text-slate-300">
                            {bootlogLines.map((l, idx) => {
                                const isLast = idx === bootlogLines.length - 1;
                                let formattedLine: React.ReactNode = l;
                                if (l.includes('OK')) {
                                    const parts = l.split('OK');
                                    formattedLine = (
                                        <>
                                            <span className="text-indigo-400 font-semibold">{parts[0].substring(0, 2)}</span>
                                            <span className="text-slate-300">{parts[0].substring(2)}</span>
                                            <span className="text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30 shadow-[0_0_8px_rgba(52,211,153,0.3)]">OK</span>
                                            {parts[1]}
                                        </>
                                    );
                                } else if (l.includes('ACCESS GRANTED')) {
                                    formattedLine = (
                                        <span className="text-cyan-300 font-bold tracking-wide">
                                            <span className="text-emerald-400 font-extrabold mr-1">&gt;</span>
                                            {l.substring(2)}
                                        </span>
                                    );
                                } else {
                                    formattedLine = (
                                        <>
                                            <span className="text-indigo-400 font-bold mr-1">&gt;</span>
                                            <span className="text-slate-300">{l.substring(2)}</span>
                                        </>
                                    );
                                }
                                return (
                                    <div key={idx} className="flex items-center gap-1 my-0.5">
                                        <div>{formattedLine}</div>
                                        {isLast && <span className="cursor-blink inline-block w-2 h-3.5 bg-cyan-400 align-middle ml-1 shadow-[0_0_8px_#38bdf8]"></span>}
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    <div className="mt-10 flex flex-wrap items-center gap-5">
                        <button onClick={() => document.getElementById('servers')?.scrollIntoView({behavior:'smooth'})}
                                className="btn-sweep group flex items-center gap-3 bg-gradient-to-r from-indigo-500 via-cyan-500 to-emerald-500 hover:from-indigo-600 hover:to-emerald-600 text-white font-display font-bold text-sm tracking-[0.2em] px-8 py-4 cursor-pointer rounded-xl shadow-[0_0_25px_rgba(99,102,241,0.35)] border border-indigo-400/30 transition-all duration-300 active:scale-[0.98]">
                            <span>GET STARTED</span>
                            <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-1 transition-transform duration-300" />
                        </button>
                        <span className="font-mono text-[10px] text-cyan-400/70 tracking-widest bg-cyan-500/10 px-3 py-1.5 rounded-lg border border-cyan-500/20">
                            READ-ONLY CONSOLE // NO AUTH REQUIRED
                        </span>
                    </div>
                </div>
            </div>

            <div className="flex justify-center mt-16">
                <div className="flex flex-col items-center gap-2 text-cyan-400/60 hover:text-cyan-400 transition-colors cursor-pointer" onClick={() => document.getElementById('servers')?.scrollIntoView({behavior:'smooth'})}>
                    <span className="font-mono text-[10px] tracking-[0.3em] uppercase font-bold">SCROLL TO FLEET</span>
                    <ChevronDown className="w-4 h-4 animate-bounce text-cyan-400" />
                </div>
            </div>
        </header>

        {/* 01 TOP SERVERS */}
        <section id="servers" className="border-t border-indigo-500/20 py-20 bg-slate-950/40">
            <div className="max-w-7xl mx-auto px-5 md:px-8">
                <div className="flex items-end justify-between mb-6 reveal">
                    <div className="flex items-center gap-4">
                        <span className="font-mono text-sm text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-md border border-indigo-500/30 font-bold">01</span>
                        <h2 className="font-display font-bold tracking-tight text-3xl md:text-5xl text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-indigo-200 flex items-center gap-3">
                            <Server className="w-8 h-8 text-indigo-400" /> MY SERVERS
                        </h2>
                    </div>
                    <span className="hidden md:flex items-center gap-2 font-mono text-[11px] text-emerald-400 font-semibold tracking-widest border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 rounded-full shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                        <span className="w-2 h-2 bg-emerald-400 rounded-full pulse-dot"></span> RANKED BY LOAD
                    </span>
                </div>
                <div className="h-px bg-gradient-to-r from-indigo-500/40 via-cyan-500/40 to-transparent mb-4"></div>

                <div className="space-y-3">
                    {myServers.length > 0 ? myServers.map((s, i) => {
                        const ok = s.status === 'online' || s.status === 'ONLINE';
                        const sparkClr = sparkColors[i % sparkColors.length];
                        return (
                            <article 
                                key={i} 
                                onClick={() => navigate(`/servers/${s.rawId}`)}
                                className={`reveal group grid grid-cols-12 items-center gap-x-4 gap-y-4 rounded-xl p-5 cursor-pointer transition-all duration-300 border ${
                                    ok 
                                    ? 'bg-slate-900/60 hover:bg-slate-900/90 border-emerald-500/30 hover:border-emerald-400/60 shadow-[0_0_20px_rgba(16,185,129,0.1)] hover:shadow-[0_0_30px_rgba(16,185,129,0.25)]' 
                                    : 'bg-slate-950/40 hover:bg-slate-900/50 border-rose-500/20 hover:border-rose-500/40'
                                }`} 
                                style={{transitionDelay: `${i*100}ms`}}
                            >
                                <div className="col-span-2 md:col-span-1 font-display font-bold text-4xl md:text-5xl text-transparent bg-clip-text bg-gradient-to-br from-indigo-400 via-cyan-300 to-slate-400 group-hover:from-cyan-300 group-hover:to-emerald-400 leading-none">
                                    {s.rank}
                                </div>
                                <div className="col-span-10 md:col-span-4">
                                    <h3 className="font-display font-bold text-xl md:text-2xl tracking-tight text-white group-hover:text-cyan-300 group-hover:translate-x-1.5 transition-all duration-300 flex items-center gap-2">
                                        {s.name}
                                    </h3>
                                    <p className="font-mono text-[11px] text-cyan-400/70 tracking-wider mt-1.5 flex items-center gap-2">
                                        <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                                        <span>{s.id}</span>
                                        <span className="text-slate-500">//</span>
                                        <span className="bg-indigo-500/10 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/20">{s.region}</span>
                                    </p>
                                </div>
                                <div className="col-span-6 md:col-span-3">
                                    {spark(i*7+3, sparkClr)}
                                </div>
                                <div className="col-span-6 md:col-span-2">
                                    <div className="flex justify-between font-mono text-[10px] tracking-widest mb-1.5">
                                        <span className="text-slate-400">LOAD</span>
                                        <span className={s.load > 70 ? 'text-rose-400 font-bold' : s.load > 40 ? 'text-amber-400 font-bold' : 'text-cyan-400 font-bold'}>
                                            {s.load}%
                                        </span>
                                    </div>
                                    <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                        <div 
                                            className={`loadbar h-full rounded-full ${
                                                s.load > 70 
                                                ? 'bg-gradient-to-r from-rose-500 to-red-400' 
                                                : s.load > 40 
                                                ? 'bg-gradient-to-r from-amber-500 to-yellow-400' 
                                                : 'bg-gradient-to-r from-emerald-500 to-cyan-400'
                                            }`} 
                                            style={{ '--w': `${s.load}%` } as React.CSSProperties}
                                        ></div>
                                    </div>
                                </div>
                                <div className="col-span-12 md:col-span-2 flex items-center md:justify-end gap-4">
                                    <div className="text-left md:text-right">
                                        <p className="font-mono text-[10px] text-slate-400 tracking-widest">UPTIME {s.uptime}%</p>
                                        <p className={`flex items-center gap-2 font-mono text-[11px] font-bold tracking-widest mt-1 ${ok ? 'text-emerald-400' : 'text-rose-400'}`}>
                                            <span className={`w-2 h-2 ${ok ? 'bg-emerald-400 pulse-dot shadow-[0_0_8px_#34d399]' : 'bg-rose-500'} rounded-full`}></span>
                                            {s.status}
                                        </p>
                                    </div>
                                    <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center group-hover:bg-cyan-500/20 group-hover:border-cyan-400/40 transition-colors">
                                        <ArrowUpRight className="w-4 h-4 text-cyan-400 group-hover:text-emerald-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-300" />
                                    </div>
                                </div>
                            </article>
                        );
                    }) : (
                        <div className="py-12 text-center border border-dashed border-indigo-500/20 rounded-xl bg-slate-950/30">
                            <p className="font-mono text-indigo-300 tracking-widest">NO SERVERS CREATED YET</p>
                        </div>
                    )}
                </div>
            </div>
        </section>

        {/* 02 OPERATORS / OTHER SERVERS */}
        {user?.role === 'admin' && (
        <section id="users" className="border-t border-purple-500/20 py-20 bg-slate-950/60">
            <div className="max-w-7xl mx-auto px-5 md:px-8">
                <div className="flex items-center justify-between mb-6 reveal">
                    <div className="flex items-center gap-4">
                        <span className="font-mono text-sm text-purple-400 bg-purple-500/10 px-2.5 py-1 rounded-md border border-purple-500/30 font-bold">02</span>
                        <h2 className="font-display font-bold tracking-tight text-3xl md:text-5xl text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-100 to-indigo-300 flex items-center gap-3">
                            <Shield className="w-8 h-8 text-purple-400" /> OTHER SERVERS
                        </h2>
                    </div>
                    <span className="hidden md:flex items-center gap-2 font-mono text-[11px] text-purple-300 font-semibold tracking-widest border border-purple-500/30 bg-purple-500/10 px-3 py-1.5 rounded-full">
                        CLEARED OPERATOR FLEET
                    </span>
                </div>
                <div className="h-px bg-gradient-to-r from-purple-500/40 via-indigo-500/40 to-transparent mb-4"></div>

                <div className="space-y-3">
                    {operatorServers.length > 0 ? (
                        operatorServers.map((s, i) => {
                            const ok = s.status === 'online' || s.status === 'ONLINE';
                            return (
                                <article 
                                    key={i} 
                                    onClick={() => navigate(`/servers/${s.rawId}`)}
                                    className={`reveal group grid grid-cols-12 items-center gap-x-4 gap-y-4 rounded-xl p-5 cursor-pointer transition-all duration-300 border ${
                                        ok 
                                        ? 'bg-slate-900/60 hover:bg-slate-900/90 border-purple-500/30 hover:border-purple-400/60 shadow-[0_0_20px_rgba(168,85,247,0.1)]' 
                                        : 'bg-slate-950/40 hover:bg-slate-900/50 border-purple-500/10'
                                    }`} 
                                    style={{transitionDelay:`${i*90}ms`}}
                                >
                                    <div className="col-span-2 md:col-span-1 font-display font-bold text-4xl md:text-5xl text-transparent bg-clip-text bg-gradient-to-br from-purple-400 to-indigo-300 group-hover:from-cyan-300 group-hover:to-purple-300 leading-none">
                                        {s.rank}
                                    </div>
                                    <div className="col-span-10 md:col-span-4">
                                        <h3 className="font-display font-bold text-xl tracking-tight text-white group-hover:text-purple-300 group-hover:translate-x-1.5 transition-all duration-300">{s.name}</h3>
                                        <p className="font-mono text-[11px] text-purple-300/70 tracking-wider mt-1 flex items-center gap-2">
                                            <Shield className="w-3.5 h-3.5 text-purple-400" />
                                            <span>OPERATOR: <span className="text-purple-200 font-bold">{s.owner?.toUpperCase() || 'EXTERNAL'}</span></span>
                                            <span className="text-slate-500">//</span>
                                            <span>{s.id}</span>
                                        </p>
                                    </div>
                                    <div className="col-span-6 md:col-span-3">
                                        {spark(i*5+2, '#a855f7')}
                                    </div>
                                    <div className="col-span-6 md:col-span-2">
                                        <div className="flex justify-between font-mono text-[10px] tracking-widest mb-1.5">
                                            <span className="text-slate-400">LOAD</span>
                                            <span className="text-purple-300 font-bold">{s.load}%</span>
                                        </div>
                                        <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                            <div className="loadbar h-full bg-gradient-to-r from-purple-500 to-indigo-400 rounded-full" style={{ '--w': `${s.load}%` } as React.CSSProperties}></div>
                                        </div>
                                    </div>
                                    <div className="col-span-12 md:col-span-2 flex items-center md:justify-end gap-4">
                                        <div className="text-left md:text-right">
                                            <p className="font-mono text-[10px] text-slate-400 tracking-widest">UPTIME {s.uptime}%</p>
                                            <p className={`flex items-center gap-2 font-mono text-[11px] font-bold tracking-widest mt-1 ${ok ? 'text-emerald-400' : 'text-slate-400'}`}>
                                                <span className={`w-2 h-2 ${ok ? 'bg-emerald-400 pulse-dot' : 'bg-slate-600'} rounded-full`}></span>
                                                {s.status}
                                            </p>
                                        </div>
                                        <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center group-hover:bg-purple-500/20 group-hover:border-purple-400/40 transition-colors">
                                            <ArrowUpRight className="w-4 h-4 text-purple-300 group-hover:text-white transition-all duration-300" />
                                        </div>
                                    </div>
                                </article>
                            );
                        })
                    ) : uniqueOwners.length > 0 ? (
                        uniqueOwners.map((u, i) => (
                            <div 
                                key={i} 
                                onClick={() => u.primaryServerId && navigate(`/servers/${u.primaryServerId}`)}
                                className={`reveal group grid grid-cols-12 items-center gap-x-4 gap-y-3 rounded-xl p-4 border border-purple-500/20 bg-slate-900/40 hover:bg-slate-900/80 ${u.primaryServerId ? 'hover:border-purple-400/50 cursor-pointer shadow-[0_0_20px_rgba(168,85,247,0.15)]' : ''} transition-all duration-300`} 
                                style={{transitionDelay:`${i*90}ms`}}
                            >
                                <div className="col-span-2 md:col-span-1 flex md:justify-center">
                                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500/20 to-indigo-500/20 border border-purple-500/40 text-purple-300 flex items-center justify-center font-display font-bold text-sm shadow-inner group-hover:border-purple-400 transition-colors">
                                        {u.init}
                                    </div>
                                </div>
                                <div className="col-span-7 md:col-span-4">
                                    <p className="font-display font-bold tracking-tight text-lg text-white group-hover:text-purple-300 group-hover:translate-x-1 transition-all">{u.name}</p>
                                    <p className="font-mono text-[10px] text-purple-300/70 tracking-widest mt-0.5">{u.role} • {u.serverCount} SERVER(S)</p>
                                </div>
                                <div className="col-span-3 md:col-span-2 md:text-center">
                                    <span className="inline-block font-mono text-[10px] tracking-widest border border-purple-500/30 bg-purple-500/10 rounded-md px-2.5 py-1 text-purple-300 font-semibold">CLR-{u.clr}</span>
                                </div>
                                <div className="hidden md:block md:col-span-2 text-center font-mono text-[11px] text-slate-400 tracking-widest">{u.ping}</div>
                                <div className="col-span-12 md:col-span-3 flex items-center justify-end gap-3">
                                    <span className={`flex items-center gap-2 font-mono text-[11px] font-bold tracking-widest ${u.on?'text-emerald-400':'text-slate-400'}`}>
                                        <span className={`w-2 h-2 rounded-full ${u.on?'bg-emerald-400 pulse-dot':'bg-slate-600'}`}></span>
                                        {u.on?'ONLINE':'OFFLINE'}
                                    </span>
                                    {u.primaryServerId && <ArrowUpRight className="w-4 h-4 text-purple-400 group-hover:text-white transition-colors" />}
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="py-12 text-center border border-dashed border-purple-500/20 rounded-xl bg-slate-950/30">
                            <p className="font-mono text-purple-300 tracking-widest">NO EXTERNAL OPERATORS FOUND</p>
                        </div>
                    )}
                </div>
            </div>
        </section>
        )}

        {/* 03 VISUAL FEED */}
        <section id="feed" className="border-t border-cyan-500/20 py-20 bg-slate-950/80 overflow-hidden">
            <div className="max-w-7xl mx-auto px-5 md:px-8 mb-10 reveal">
                <div className="flex items-center gap-4">
                    <span className="font-mono text-sm text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-md border border-cyan-500/30 font-bold">03</span>
                    <h2 className="font-display font-bold tracking-tight text-3xl md:text-5xl text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-emerald-200">
                        VISUAL FEED
                    </h2>
                </div>
                <p className="text-cyan-300/70 font-light mt-3 max-w-md">Physical layer — datacenter & server telemetry imagery streamed live from active availability zones.</p>
            </div>

            <div className="space-y-6">
                <div className="overflow-hidden">
                    <div className="marquee">
                        {[...feedA, ...feedA].map(([img, idx, cap], i) => (
                            <figure key={i} className="group relative flex-shrink-0 w-[78vw] md:w-[500px] aspect-[16/10] overflow-hidden rounded-2xl border border-cyan-500/20 bg-slate-900 shadow-xl hover:border-cyan-400/60 transition-all duration-300">
                                <img src={img} alt={cap} loading="lazy"
                                     className="bw-img absolute inset-0 w-full h-full object-cover" />
                                <span className="absolute top-3 left-3 font-mono text-[10px] tracking-widest text-white bg-gradient-to-r from-indigo-600 to-cyan-600 px-2.5 py-1 rounded-md shadow-md z-10 font-bold">{idx}</span>
                                <figcaption className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                                    <p className="font-mono text-[11px] tracking-widest text-cyan-300 font-bold">{cap}</p>
                                </figcaption>
                            </figure>
                        ))}
                    </div>
                </div>
                <div className="overflow-hidden">
                    <div className="marquee rev">
                        {[...feedB, ...feedB].map(([img, idx, cap], i) => (
                            <figure key={i} className="group relative flex-shrink-0 w-[78vw] md:w-[500px] aspect-[16/10] overflow-hidden rounded-2xl border border-indigo-500/20 bg-slate-900 shadow-xl hover:border-indigo-400/60 transition-all duration-300">
                                <img src={img} alt={cap} loading="lazy"
                                     className="bw-img absolute inset-0 w-full h-full object-cover" />
                                <span className="absolute top-3 left-3 font-mono text-[10px] tracking-widest text-white bg-gradient-to-r from-purple-600 to-indigo-600 px-2.5 py-1 rounded-md shadow-md z-10 font-bold">{idx}</span>
                                <figcaption className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                                    <p className="font-mono text-[11px] tracking-widest text-indigo-300 font-bold">{cap}</p>
                                </figcaption>
                            </figure>
                        ))}
                    </div>
                </div>
            </div>
        </section>

        {/* FOOTER */}
        <footer className="border-t border-indigo-500/20 bg-slate-950">
            <div className="overflow-hidden select-none" aria-hidden="true">
                <p className="outline-faint font-display font-bold text-[19vw] leading-[0.78] text-center -mb-[3.5vw] uppercase text-slate-800/20">{firstWord}</p>
            </div>
            <div className="border-t border-indigo-500/20">
                <div className="max-w-7xl mx-auto px-5 md:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
                    <span className="font-mono text-[10px] text-slate-400 tracking-[0.25em]">© 2026 {pName.toUpperCase()} — INFRASTRUCTURE COMMAND</span>
                    <div className="flex items-center gap-6 font-mono text-[10px] text-cyan-400/70 tracking-widest">
                        <a href="#servers" className="hover:text-cyan-300 transition-colors">SERVERS</a>
                        {user?.role === 'admin' && <a href="#users" className="hover:text-purple-300 transition-colors">OTHER SERVERS</a>}
                        <a href="#feed" className="hover:text-emerald-300 transition-colors">FEED</a>
                    </div>
                </div>
            </div>
        </footer>
      </div>
    </div>
  );
}
